// 325764215 Noam Leabovich

/**
 * The interface interfaces.Border.
 */
public interface Border {
    /**
     * Crosses the border.
     */
    void crossesTheBorder();
}
