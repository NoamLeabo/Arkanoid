// 325764215 Noam Leabovich
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;

/**
 * The type End screen.
 */
public class EndScreen implements Animation {
    /**
     * The constant M2.
     */
    public static final int M2 = 2;
    /**
     * The constant X.
     */
    public static final int X = 10;
    /**
     * The constant FONT.
     */
    public static final int FONT = 32;
    private KeyboardSensor keyboard;
    private boolean stop;
    private ScoreTrackingListener scoreTrackingListener;
    private boolean win;

    /**
     * Instantiates a new End screen.
     *
     * @param k                     the KeyboardSensor
     * @param scoreTrackingListener the score tracking listener
     * @param win                   the win indicator
     */
    public EndScreen(KeyboardSensor k,
                     ScoreTrackingListener scoreTrackingListener,
                     boolean win) {
        this.keyboard = k;
        this.stop = false;
        this.scoreTrackingListener = scoreTrackingListener;
        this.win = win;
    }

    @Override
    public void doOneFrame(DrawSurface d) {
        //if a win is occurred show an end screen of a win
        if (win) {
            d.drawText(X, d.getHeight() / M2,
                    "You Win! Your score is "
                            + this.scoreTrackingListener.getCurrentScore()
                            .getValue(), FONT);
        } else {
            //if a lost is occurred show an end screen of a lost
            d.drawText(X, d.getHeight() / M2,
                    "Game Over. Your score is "
                            + this.scoreTrackingListener.getCurrentScore()
                            .getValue(), FONT);
        }
    }

    /**
     * Should stop boolean.
     *
     * @return the boolean whether it shouldStop or not
     */
    public boolean shouldStop() {
        return this.stop;
    }
}