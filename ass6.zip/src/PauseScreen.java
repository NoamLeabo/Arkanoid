// 325764215 Noam Leabovich
import biuoop.DrawSurface;


/**
 * The type Pause screen.
 */
public class PauseScreen implements Animation {
    /**
     * The constant X.
     */
    public static final int X = 10;
    /**
     * The constant FONT.
     */
    public static final int FONT = 32;
    private boolean stop;

    /**
     * Instantiates a new Pause screen.
     *
     */
    public PauseScreen() {
        this.stop = false;
    }

    @Override
    public void doOneFrame(DrawSurface d) {
        //we do on frame of the pause screen
        d.drawText(X, d.getHeight() / 2,
                "paused -- press space to continue",
                FONT);
    }
    /**
     * Should stop boolean.
     *
     * @return the boolean whether it shouldStop or not
     */
    public boolean shouldStop() {
        return this.stop;
    }
}