// 325764215 Noam Leabovich

/**
 * The type Game.Counter for lines.
 */
public class CounterForLines extends Counter {

    /**
     * Instantiates a new Game.Counter for lines.
     *
     * @param initialNum    the initial num
     * @param blocksPerLine the blocks per line
     */
    public CounterForLines(int initialNum, Integer[] blocksPerLine) {
        super(initialNum);
    }

}
