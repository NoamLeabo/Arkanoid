// 325764215 Noam Leabovich


/**
 * The type Graphics.Block remover.
 */
public class BlockRemover implements HitListener {
    private final GameLevel game;
    private final Counter remainingBlocks;


    /**
     * Instantiates a new Graphics.Block remover.
     *
     * @param game    the game
     * @param counter the counter
     */
    public BlockRemover(GameLevel game, Counter counter) {
        this.game = game;
        this.remainingBlocks = counter;
    }

    /**
     * Hit event.
     * Blocks that are hit should be removed
     * from the game. Remember to remove this listener from the block
     * that is being removed from the game.
     *
     * @param beingHit the being hit
     * @param hitter   the hitter
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        //making sure the block is not a border
            //remove the block being hit from the game
            beingHit.removeFromGame(game);
            //updating the new number of remaining block in the game
            remainingBlocks.decrease(1);
            //updating the new number of remaining blocks in each line
    }
}
